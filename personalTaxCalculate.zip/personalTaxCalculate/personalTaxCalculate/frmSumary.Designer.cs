﻿namespace personalTaxCalculate
{
    partial class frmSumary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnNext = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblExemsionDonate = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblExemsionRelationStatus = new System.Windows.Forms.Label();
            this.lbl = new System.Windows.Forms.Label();
            this.lblExemsionInterrestHome = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblExemsionRMF = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblExemsionLTF = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblExemsionInsurance = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblExemsionSocailInsurance = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblExemsionCripple = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblExemsionParent = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblExemsionChilden = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblExemsionPersonal = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblPersonalSalary = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblRelationStatus = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblPersonalID = new System.Windows.Forms.Label();
            this.lblBirthDate = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.picPerson = new System.Windows.Forms.PictureBox();
            this.picRelation = new System.Windows.Forms.PictureBox();
            this.picChliden = new System.Windows.Forms.PictureBox();
            this.picInterestHome = new System.Windows.Forms.PictureBox();
            this.picRMF = new System.Windows.Forms.PictureBox();
            this.picLTF = new System.Windows.Forms.PictureBox();
            this.picInsurance = new System.Windows.Forms.PictureBox();
            this.picSocialInsurance = new System.Windows.Forms.PictureBox();
            this.picCripple = new System.Windows.Forms.PictureBox();
            this.picParents = new System.Windows.Forms.PictureBox();
            this.picDonate = new System.Windows.Forms.PictureBox();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPerson)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRelation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChliden)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInterestHome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRMF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLTF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInsurance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSocialInsurance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCripple)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picParents)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDonate)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(784, 60);
            this.panel1.TabIndex = 31;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnNext);
            this.panel4.Controls.Add(this.button3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 701);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(784, 60);
            this.panel4.TabIndex = 34;
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(674, 25);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(98, 23);
            this.btnNext.TabIndex = 17;
            this.btnNext.Text = "ต่อไป";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(17, 19);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(98, 23);
            this.button3.TabIndex = 16;
            this.button3.Text = "ย้อนกลับ";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 60);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(784, 641);
            this.panel2.TabIndex = 35;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::personalTaxCalculate.Properties.Resources.presentation_12;
            this.pictureBox1.Location = new System.Drawing.Point(332, 15);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.picDonate);
            this.groupBox3.Controls.Add(this.picParents);
            this.groupBox3.Controls.Add(this.picCripple);
            this.groupBox3.Controls.Add(this.picSocialInsurance);
            this.groupBox3.Controls.Add(this.picInsurance);
            this.groupBox3.Controls.Add(this.picLTF);
            this.groupBox3.Controls.Add(this.picRMF);
            this.groupBox3.Controls.Add(this.picInterestHome);
            this.groupBox3.Controls.Add(this.picChliden);
            this.groupBox3.Controls.Add(this.picRelation);
            this.groupBox3.Controls.Add(this.picPerson);
            this.groupBox3.Controls.Add(this.lblExemsionDonate);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.lblExemsionRelationStatus);
            this.groupBox3.Controls.Add(this.lbl);
            this.groupBox3.Controls.Add(this.lblExemsionInterrestHome);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.lblExemsionRMF);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.lblExemsionLTF);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.lblExemsionInsurance);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.lblExemsionSocailInsurance);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.lblExemsionCripple);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.lblExemsionParent);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.lblExemsionChilden);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.lblExemsionPersonal);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.groupBox3.Location = new System.Drawing.Point(12, 534);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(747, 543);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ข้อมูลลดหย่อน";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // lblExemsionDonate
            // 
            this.lblExemsionDonate.AutoSize = true;
            this.lblExemsionDonate.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblExemsionDonate.Location = new System.Drawing.Point(266, 490);
            this.lblExemsionDonate.Name = "lblExemsionDonate";
            this.lblExemsionDonate.Size = new System.Drawing.Size(19, 25);
            this.lblExemsionDonate.TabIndex = 35;
            this.lblExemsionDonate.Text = "-";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(30, 490);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(123, 25);
            this.label16.TabIndex = 34;
            this.label16.Text = "11.เงินบริจาค";
            // 
            // lblExemsionRelationStatus
            // 
            this.lblExemsionRelationStatus.AutoSize = true;
            this.lblExemsionRelationStatus.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblExemsionRelationStatus.Location = new System.Drawing.Point(266, 99);
            this.lblExemsionRelationStatus.Name = "lblExemsionRelationStatus";
            this.lblExemsionRelationStatus.Size = new System.Drawing.Size(19, 25);
            this.lblExemsionRelationStatus.TabIndex = 33;
            this.lblExemsionRelationStatus.Text = "-";
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Location = new System.Drawing.Point(30, 99);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(86, 25);
            this.lbl.TabIndex = 32;
            this.lbl.Text = "2.คู่สมรส";
            // 
            // lblExemsionInterrestHome
            // 
            this.lblExemsionInterrestHome.AutoSize = true;
            this.lblExemsionInterrestHome.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblExemsionInterrestHome.Location = new System.Drawing.Point(266, 451);
            this.lblExemsionInterrestHome.Name = "lblExemsionInterrestHome";
            this.lblExemsionInterrestHome.Size = new System.Drawing.Size(19, 25);
            this.lblExemsionInterrestHome.TabIndex = 31;
            this.lblExemsionInterrestHome.Text = "-";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(30, 451);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(206, 25);
            this.label14.TabIndex = 30;
            this.label14.Text = "10.ดอกเบี้ยซื้อที่อยู่อาศัย";
            // 
            // lblExemsionRMF
            // 
            this.lblExemsionRMF.AutoSize = true;
            this.lblExemsionRMF.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblExemsionRMF.Location = new System.Drawing.Point(266, 410);
            this.lblExemsionRMF.Name = "lblExemsionRMF";
            this.lblExemsionRMF.Size = new System.Drawing.Size(19, 25);
            this.lblExemsionRMF.TabIndex = 29;
            this.lblExemsionRMF.Text = "-";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(30, 410);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(122, 25);
            this.label13.TabIndex = 28;
            this.label13.Text = "9.กองทุนอื่นๆ";
            // 
            // lblExemsionLTF
            // 
            this.lblExemsionLTF.AutoSize = true;
            this.lblExemsionLTF.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblExemsionLTF.Location = new System.Drawing.Point(266, 365);
            this.lblExemsionLTF.Name = "lblExemsionLTF";
            this.lblExemsionLTF.Size = new System.Drawing.Size(19, 25);
            this.lblExemsionLTF.TabIndex = 27;
            this.lblExemsionLTF.Text = "-";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(30, 365);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 25);
            this.label15.TabIndex = 26;
            this.label15.Text = "8.LTF";
            // 
            // lblExemsionInsurance
            // 
            this.lblExemsionInsurance.AutoSize = true;
            this.lblExemsionInsurance.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblExemsionInsurance.Location = new System.Drawing.Point(266, 320);
            this.lblExemsionInsurance.Name = "lblExemsionInsurance";
            this.lblExemsionInsurance.Size = new System.Drawing.Size(19, 25);
            this.lblExemsionInsurance.TabIndex = 25;
            this.lblExemsionInsurance.Text = "-";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(30, 320);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(147, 25);
            this.label17.TabIndex = 24;
            this.label17.Text = "7.เงินประกันชีวิต";
            // 
            // lblExemsionSocailInsurance
            // 
            this.lblExemsionSocailInsurance.AutoSize = true;
            this.lblExemsionSocailInsurance.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblExemsionSocailInsurance.Location = new System.Drawing.Point(266, 280);
            this.lblExemsionSocailInsurance.Name = "lblExemsionSocailInsurance";
            this.lblExemsionSocailInsurance.Size = new System.Drawing.Size(19, 25);
            this.lblExemsionSocailInsurance.TabIndex = 23;
            this.lblExemsionSocailInsurance.Text = "-";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(30, 280);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(157, 25);
            this.label12.TabIndex = 22;
            this.label12.Text = "6.เงินประกันสังคม";
            // 
            // lblExemsionCripple
            // 
            this.lblExemsionCripple.AutoSize = true;
            this.lblExemsionCripple.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblExemsionCripple.Location = new System.Drawing.Point(266, 235);
            this.lblExemsionCripple.Name = "lblExemsionCripple";
            this.lblExemsionCripple.Size = new System.Drawing.Size(19, 25);
            this.lblExemsionCripple.TabIndex = 21;
            this.lblExemsionCripple.Text = "-";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(30, 235);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 25);
            this.label11.TabIndex = 20;
            this.label11.Text = "5.คนพิการ";
            // 
            // lblExemsionParent
            // 
            this.lblExemsionParent.AutoSize = true;
            this.lblExemsionParent.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblExemsionParent.Location = new System.Drawing.Point(266, 190);
            this.lblExemsionParent.Name = "lblExemsionParent";
            this.lblExemsionParent.Size = new System.Drawing.Size(19, 25);
            this.lblExemsionParent.TabIndex = 19;
            this.lblExemsionParent.Text = "-";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(30, 190);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 25);
            this.label10.TabIndex = 18;
            this.label10.Text = "4.บิดา มารดา";
            // 
            // lblExemsionChilden
            // 
            this.lblExemsionChilden.AutoSize = true;
            this.lblExemsionChilden.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblExemsionChilden.Location = new System.Drawing.Point(266, 145);
            this.lblExemsionChilden.Name = "lblExemsionChilden";
            this.lblExemsionChilden.Size = new System.Drawing.Size(19, 25);
            this.lblExemsionChilden.TabIndex = 17;
            this.lblExemsionChilden.Text = "-";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(30, 145);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 25);
            this.label8.TabIndex = 16;
            this.label8.Text = "3.บุตร";
            // 
            // lblExemsionPersonal
            // 
            this.lblExemsionPersonal.AutoSize = true;
            this.lblExemsionPersonal.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblExemsionPersonal.Location = new System.Drawing.Point(266, 50);
            this.lblExemsionPersonal.Name = "lblExemsionPersonal";
            this.lblExemsionPersonal.Size = new System.Drawing.Size(19, 25);
            this.lblExemsionPersonal.TabIndex = 15;
            this.lblExemsionPersonal.Text = "-";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(30, 50);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 25);
            this.label7.TabIndex = 14;
            this.label7.Text = "1.ส่วนตัว";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblPersonalSalary);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.groupBox2.Location = new System.Drawing.Point(12, 417);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(747, 111);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ข้อมูลรายได้";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // lblPersonalSalary
            // 
            this.lblPersonalSalary.AutoSize = true;
            this.lblPersonalSalary.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblPersonalSalary.Location = new System.Drawing.Point(261, 54);
            this.lblPersonalSalary.Name = "lblPersonalSalary";
            this.lblPersonalSalary.Size = new System.Drawing.Size(19, 25);
            this.lblPersonalSalary.TabIndex = 13;
            this.lblPersonalSalary.Text = "-";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 54);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 25);
            this.label6.TabIndex = 12;
            this.label6.Text = "เงินเดือนต่อปี";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblRelationStatus);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.lblPersonalID);
            this.groupBox1.Controls.Add(this.lblBirthDate);
            this.groupBox1.Controls.Add(this.lblFirstName);
            this.groupBox1.Controls.Add(this.lblLastName);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.groupBox1.Location = new System.Drawing.Point(12, 149);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(747, 242);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ข้อมูลส่วนตัว";
            // 
            // lblRelationStatus
            // 
            this.lblRelationStatus.AutoSize = true;
            this.lblRelationStatus.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblRelationStatus.Location = new System.Drawing.Point(261, 188);
            this.lblRelationStatus.Name = "lblRelationStatus";
            this.lblRelationStatus.Size = new System.Drawing.Size(19, 25);
            this.lblRelationStatus.TabIndex = 16;
            this.lblRelationStatus.Text = "-";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(25, 188);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 25);
            this.label9.TabIndex = 15;
            this.label9.Text = "สถานภาพ";
            // 
            // lblPersonalID
            // 
            this.lblPersonalID.AutoSize = true;
            this.lblPersonalID.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblPersonalID.Location = new System.Drawing.Point(261, 43);
            this.lblPersonalID.Name = "lblPersonalID";
            this.lblPersonalID.Size = new System.Drawing.Size(19, 25);
            this.lblPersonalID.TabIndex = 11;
            this.lblPersonalID.Text = "-";
            // 
            // lblBirthDate
            // 
            this.lblBirthDate.AutoSize = true;
            this.lblBirthDate.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblBirthDate.Location = new System.Drawing.Point(261, 150);
            this.lblBirthDate.Name = "lblBirthDate";
            this.lblBirthDate.Size = new System.Drawing.Size(19, 25);
            this.lblBirthDate.TabIndex = 14;
            this.lblBirthDate.Text = "-";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblFirstName.Location = new System.Drawing.Point(261, 80);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(19, 25);
            this.lblFirstName.TabIndex = 12;
            this.lblFirstName.Text = "-";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblLastName.Location = new System.Drawing.Point(261, 115);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(19, 25);
            this.lblLastName.TabIndex = 13;
            this.lblLastName.Text = "-";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 25);
            this.label1.TabIndex = 7;
            this.label1.Text = "เลขที่บัตรประชาชน";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 25);
            this.label4.TabIndex = 10;
            this.label4.Text = "วันเดือนปีเกิด";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 25);
            this.label2.TabIndex = 8;
            this.label2.Text = "ชื่อ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 25);
            this.label3.TabIndex = 9;
            this.label3.Text = "นามสกุล";
            // 
            // picPerson
            // 
            this.picPerson.Image = global::personalTaxCalculate.Properties.Resources.info_512pxGREY;
            this.picPerson.Location = new System.Drawing.Point(569, 50);
            this.picPerson.Name = "picPerson";
            this.picPerson.Size = new System.Drawing.Size(32, 32);
            this.picPerson.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPerson.TabIndex = 36;
            this.picPerson.TabStop = false;
            this.picPerson.Click += new System.EventHandler(this.picPerson_Click);
            // 
            // picRelation
            // 
            this.picRelation.Image = global::personalTaxCalculate.Properties.Resources.info_512pxGREY;
            this.picRelation.Location = new System.Drawing.Point(569, 92);
            this.picRelation.Name = "picRelation";
            this.picRelation.Size = new System.Drawing.Size(32, 32);
            this.picRelation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picRelation.TabIndex = 37;
            this.picRelation.TabStop = false;
            this.picRelation.Click += new System.EventHandler(this.picRelation_Click);
            // 
            // picChliden
            // 
            this.picChliden.Image = global::personalTaxCalculate.Properties.Resources.info_512pxGREY;
            this.picChliden.Location = new System.Drawing.Point(569, 138);
            this.picChliden.Name = "picChliden";
            this.picChliden.Size = new System.Drawing.Size(32, 32);
            this.picChliden.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picChliden.TabIndex = 38;
            this.picChliden.TabStop = false;
            this.picChliden.Click += new System.EventHandler(this.picChliden_Click);
            // 
            // picInterestHome
            // 
            this.picInterestHome.Image = global::personalTaxCalculate.Properties.Resources.info_512pxGREY;
            this.picInterestHome.Location = new System.Drawing.Point(569, 444);
            this.picInterestHome.Name = "picInterestHome";
            this.picInterestHome.Size = new System.Drawing.Size(32, 32);
            this.picInterestHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picInterestHome.TabIndex = 39;
            this.picInterestHome.TabStop = false;
            this.picInterestHome.Click += new System.EventHandler(this.picInterestHome_Click);
            // 
            // picRMF
            // 
            this.picRMF.Image = global::personalTaxCalculate.Properties.Resources.info_512pxGREY;
            this.picRMF.Location = new System.Drawing.Point(569, 403);
            this.picRMF.Name = "picRMF";
            this.picRMF.Size = new System.Drawing.Size(32, 32);
            this.picRMF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picRMF.TabIndex = 40;
            this.picRMF.TabStop = false;
            this.picRMF.Click += new System.EventHandler(this.picRMF_Click);
            // 
            // picLTF
            // 
            this.picLTF.Image = global::personalTaxCalculate.Properties.Resources.info_512pxGREY;
            this.picLTF.Location = new System.Drawing.Point(569, 358);
            this.picLTF.Name = "picLTF";
            this.picLTF.Size = new System.Drawing.Size(32, 32);
            this.picLTF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLTF.TabIndex = 41;
            this.picLTF.TabStop = false;
            this.picLTF.Click += new System.EventHandler(this.picLTF_Click);
            // 
            // picInsurance
            // 
            this.picInsurance.Image = global::personalTaxCalculate.Properties.Resources.info_512pxGREY;
            this.picInsurance.Location = new System.Drawing.Point(569, 320);
            this.picInsurance.Name = "picInsurance";
            this.picInsurance.Size = new System.Drawing.Size(32, 32);
            this.picInsurance.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picInsurance.TabIndex = 42;
            this.picInsurance.TabStop = false;
            this.picInsurance.Click += new System.EventHandler(this.picInsurance_Click);
            // 
            // picSocialInsurance
            // 
            this.picSocialInsurance.Image = global::personalTaxCalculate.Properties.Resources.info_512pxGREY;
            this.picSocialInsurance.Location = new System.Drawing.Point(569, 273);
            this.picSocialInsurance.Name = "picSocialInsurance";
            this.picSocialInsurance.Size = new System.Drawing.Size(32, 32);
            this.picSocialInsurance.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSocialInsurance.TabIndex = 43;
            this.picSocialInsurance.TabStop = false;
            this.picSocialInsurance.Click += new System.EventHandler(this.picSocialInsurance_Click);
            // 
            // picCripple
            // 
            this.picCripple.Image = global::personalTaxCalculate.Properties.Resources.info_512pxGREY;
            this.picCripple.Location = new System.Drawing.Point(569, 228);
            this.picCripple.Name = "picCripple";
            this.picCripple.Size = new System.Drawing.Size(32, 32);
            this.picCripple.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCripple.TabIndex = 44;
            this.picCripple.TabStop = false;
            this.picCripple.Click += new System.EventHandler(this.picCripple_Click);
            // 
            // picParents
            // 
            this.picParents.Image = global::personalTaxCalculate.Properties.Resources.info_512pxGREY;
            this.picParents.Location = new System.Drawing.Point(569, 183);
            this.picParents.Name = "picParents";
            this.picParents.Size = new System.Drawing.Size(32, 32);
            this.picParents.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picParents.TabIndex = 45;
            this.picParents.TabStop = false;
            this.picParents.Click += new System.EventHandler(this.picParents_Click);
            // 
            // picDonate
            // 
            this.picDonate.Image = global::personalTaxCalculate.Properties.Resources.info_512pxGREY;
            this.picDonate.Location = new System.Drawing.Point(569, 482);
            this.picDonate.Name = "picDonate";
            this.picDonate.Size = new System.Drawing.Size(32, 32);
            this.picDonate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDonate.TabIndex = 46;
            this.picDonate.TabStop = false;
            this.picDonate.Click += new System.EventHandler(this.picDonate_Click);
            // 
            // frmSumary
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(784, 761);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Name = "frmSumary";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmSumary";
            this.Load += new System.EventHandler(this.frmSumary_Load);
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPerson)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRelation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChliden)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInterestHome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRMF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLTF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInsurance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSocialInsurance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCripple)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picParents)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDonate)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblPersonalID;
        private System.Windows.Forms.Label lblBirthDate;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label lblPersonalSalary;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblExemsionPersonal;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblRelationStatus;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblExemsionChilden;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblExemsionParent;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblExemsionCripple;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblExemsionSocailInsurance;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblExemsionRMF;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblExemsionLTF;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblExemsionInsurance;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblExemsionInterrestHome;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblExemsionRelationStatus;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.Label lblExemsionDonate;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox picDonate;
        private System.Windows.Forms.PictureBox picParents;
        private System.Windows.Forms.PictureBox picCripple;
        private System.Windows.Forms.PictureBox picSocialInsurance;
        private System.Windows.Forms.PictureBox picInsurance;
        private System.Windows.Forms.PictureBox picLTF;
        private System.Windows.Forms.PictureBox picRMF;
        private System.Windows.Forms.PictureBox picInterestHome;
        private System.Windows.Forms.PictureBox picChliden;
        private System.Windows.Forms.PictureBox picRelation;
        private System.Windows.Forms.PictureBox picPerson;
    }
}