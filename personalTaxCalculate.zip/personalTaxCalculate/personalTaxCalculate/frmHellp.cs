﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace personalTaxCalculate
{
    public partial class frmHellp : Form
    {
        public frmHellp()
        {
            InitializeComponent();
        }

        private void frmHellp_Load(object sender, EventArgs e)
        {
            
        }

        
    }
}
